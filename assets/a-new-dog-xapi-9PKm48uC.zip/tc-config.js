/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://fAiifW2Rfm7n9-TqthYbkn-IvFccdEo4_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "A New Dog"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": ""
};
